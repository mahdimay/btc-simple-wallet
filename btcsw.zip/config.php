<?PHP
$host= "HOST";
$dbuser = "DBUSER";
$dbpass = "DBPASS";
$dbname = "DBNAME";
$con = new mysqli ($host, $dbuser,$dbpass,$dbname);
